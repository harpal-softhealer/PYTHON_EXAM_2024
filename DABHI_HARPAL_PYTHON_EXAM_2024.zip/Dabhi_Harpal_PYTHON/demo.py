n = int(input("Enter NUmber : "))

for i in range(1,3+n):
    if i>n:
        print((n-1)*" ",end="")
        print("*")
    else:
        print((n-i)*" ",end="")
        print(((i*2)-1)*"*",end="")
        print()