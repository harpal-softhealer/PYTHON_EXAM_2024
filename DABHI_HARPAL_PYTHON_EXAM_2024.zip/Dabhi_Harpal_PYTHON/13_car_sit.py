cars = list(input("Enter How may N and M cars ?? "))

car_ = [car for car in cars if car.isnumeric()]

print(car_)

def count_siting(N,M):
    print(f"N car have total : {N*5}")
    print(f"M car have total : {M*7}")

    sum = N*5 + M*7

    print(f"Total number people can travel : {sum}")

count_siting(int(car_[0]),int(car_[1]))