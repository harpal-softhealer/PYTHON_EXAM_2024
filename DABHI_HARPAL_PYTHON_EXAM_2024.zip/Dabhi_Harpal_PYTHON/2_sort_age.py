li = [
{'name': 'Homer', 'age': 39},
{'name': 'Bart', 'age': 10},
{'name': "Ketan", 'age': 5},
{'name': "Sagar", 'age': 50}

]

ages = []

for i in li:
    ages.append(i["age"])


sorte_age = sorted(ages)

sorted_dict = []

for i in sorte_age:
    for dct in li:
        if i==dct['age']:
            sorted_dict.append(dct)

else:
    print(sorted_dict)