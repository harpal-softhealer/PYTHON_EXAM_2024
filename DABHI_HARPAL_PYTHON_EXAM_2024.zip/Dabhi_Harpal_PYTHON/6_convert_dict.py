keys_ = ['Ten', 'Twenty', 'Thirty']
values_ = [10, 20, 30]

dict_ = dict(zip(keys_,values_))

print(dict_)