sample_dict = {
    "class":{
        "student":{
            "name":"Mike",
            "Marks":{
                "physics": 70,
                "history":80
            }
        }
    }
}


answer = sample_dict["class"]["student"]["Marks"]["history"]

print(answer)