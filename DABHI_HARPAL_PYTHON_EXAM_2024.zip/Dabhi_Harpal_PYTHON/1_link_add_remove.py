links = [
"/blog/tag/tag-a-1",
"/blog/tag/tag-b-2"
"https://softhealer.com/blog/career-5/feed",
"https://softhealer.com/blog/odoo-2/feed",
"https://softhealer.com/blog/career-5/unforgettable-gir-trip-2086",
"https://softhealer.com/blog/career-5/christmas-celebration-2022-1954",
"https://softhealer.com/shop/product/accounting-fiscal-year-565",
"https://softhealer.com/shop/product/accounting-transaction-charges-407",
]

posts = []

products = []

for i in links:
    if "career-5" in i:
        new = i.replace("career-5","career-5/post")
        posts.append(new)
    if "product" in i:
        new = i.replace("/product","")
        products.append(new)



for i in products:
    print(i)

print("_______________")

for i in posts:
    print(i)