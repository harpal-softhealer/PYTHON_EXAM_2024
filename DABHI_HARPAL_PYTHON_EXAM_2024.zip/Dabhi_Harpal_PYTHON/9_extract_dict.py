sample_dict = {
    "name":"Kelly",
    "age":25,
    "salary":8000,
    "city":"New York"
}


keys_ = ["name","salary"]


new_dict = {}

for i in keys_:
    new_dict.update({i: sample_dict[i]})

else:
    print(new_dict)