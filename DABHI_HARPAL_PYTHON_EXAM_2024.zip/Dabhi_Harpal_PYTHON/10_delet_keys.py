sample_dict = {
    "name":"Kelly",
    "age":25,
    "salary":8000,
    "city":"New York"
}


keys_ = ["name","salary"]


for i in keys_:
    del sample_dict[i]
else:
    print(sample_dict)

