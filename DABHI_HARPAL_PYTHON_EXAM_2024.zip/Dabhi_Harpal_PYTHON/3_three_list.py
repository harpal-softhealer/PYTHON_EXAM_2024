name = ['Snowball', 'Chewy', 'Bubbles', 'Gruff']
animal = ['Cat', 'Dog', 'Fish', 'Goat']
age = [1, 2, 2, 6]


for i  in range(len(name)):
    print(f"{name[i]} the {animal[i]} is {age[i]}")