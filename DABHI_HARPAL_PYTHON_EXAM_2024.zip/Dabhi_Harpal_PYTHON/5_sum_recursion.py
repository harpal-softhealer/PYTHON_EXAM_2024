n = int(input("Enter Number"))
sum = 0

def num_sum(n):
    if n>1:
        return n+num_sum(n-1)
    else:
        return 1

print(f"Sum of {n} is {num_sum(n)}")
