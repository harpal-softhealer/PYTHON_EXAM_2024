input_rolls = list(input("Enter number : "))

rolls = [roll for roll in input_rolls if roll.isnumeric()]

def is_win(rolls):
    sum = 0
    for i in rolls:
        sum = sum + int(i)
    else:
        if sum>6:
            print("Yes")
        else:
            print("No")

is_win(rolls)
